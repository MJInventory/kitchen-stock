const sheetDate = document.querySelector("#sheetDate");
const driverName = document.querySelector("#driverName");
const loadSheetButton = document.querySelector("#loadSheetButton");
const printSheetButton = document.querySelector("#printSheetButton");
const sheetMessage = document.querySelector("#sheetMessage");
const printDate = document.querySelector("#printDate");
const printDriver = document.querySelector("#printDriver");
const sheetList = document.querySelector("#sheetList");

function todayLocal() {
  const now = new Date();
  const offset = now.getTimezoneOffset();
  return new Date(now.getTime() - offset * 60000).toISOString().slice(0, 10);
}

function setMessage(text, isError = false) {
  sheetMessage.textContent = text;
  sheetMessage.classList.toggle("error", isError);
}

function groupRequests(requests) {
  return requests.reduce((groups, request) => {
    const key = [request.inventoryArea || "Unassigned", request.storageLocation || "No location"].join(" - ");
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(request);
    return groups;
  }, new Map());
}

function renderSheet(data) {
  printDate.textContent = `Date: ${data.date}`;
  printDriver.textContent = `Driver: ${driverName.value || "________________"}`;

  if (!data.requests.length) {
    sheetList.innerHTML = '<p class="empty-sheet">No pending or approved requests for this date.</p>';
    return;
  }

  const groups = groupRequests(data.requests);
  sheetList.innerHTML = [...groups.entries()]
    .map(([group, requests]) => `
      <section class="sheet-group">
        <h2>${group}</h2>
        <table>
          <thead>
            <tr>
              <th>Picked</th>
              <th>Item</th>
              <th>Qty</th>
              <th>Unit</th>
              <th>Urgency</th>
              <th>Status</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            ${requests
              .map((request) => `
                <tr>
                  <td class="check-cell"></td>
                  <td>${request.itemName}</td>
                  <td>${request.quantity ?? ""}</td>
                  <td>${request.unit || ""}</td>
                  <td>${request.urgency || ""}</td>
                  <td>${request.status || ""}</td>
                  <td>${request.notes || ""}</td>
                </tr>
              `)
              .join("")}
          </tbody>
        </table>
      </section>
    `)
    .join("");
}

async function loadSheet() {
  setMessage("Loading...");
  const response = await fetch(`/api/driver-sheet?date=${encodeURIComponent(sheetDate.value)}`);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Could not load driver sheet.");
  renderSheet(data);
  setMessage("");
}

sheetDate.value = todayLocal();
loadSheetButton.addEventListener("click", () => loadSheet().catch((error) => setMessage(error.message, true)));
driverName.addEventListener("input", () => {
  printDriver.textContent = `Driver: ${driverName.value || "________________"}`;
});
printSheetButton.addEventListener("click", () => window.print());

loadSheet().catch((error) => setMessage(error.message, true));
